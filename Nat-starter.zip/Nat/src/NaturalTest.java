import static org.junit.Assert.*;

import org.junit.Test;

import com.google.java.contract.PreconditionError;


public class NaturalTest {

	@Test
	public void test() {
		
	}

}
